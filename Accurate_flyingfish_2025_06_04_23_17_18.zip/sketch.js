function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let trees = [];  // Lista para armazenar as árvores

// Classe para a árvore
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.age = 0;  // A idade da árvore vai determinar seu tamanho
    this.isGrown = false;
  }

  // Método para simular o crescimento da árvore
  grow() {
    if (!this.isGrown) {
      this.age++;
      if (this.age >= 100) {
        this.isGrown = true;  // A árvore se torna adulta
      }
    }
  }

  // Desenha a árvore na tela
  display() {
    noStroke();
    if (this.isGrown) {
      fill(34, 139, 34);  // Cor para árvore adulta (verde)
      ellipse(this.x, this.y - 10, 40, 40);  // Folhas
      fill(139, 69, 19);  // Cor para o tronco (marrom)
      rect(this.x - 5, this.y, 10, 40);  // Tronco
    } else {
      fill(139, 69, 19);  // Tronco pequeno
      rect(this.x - 2, this.y, 4, 10);  // Tronco
    }
  }

  // Método para colher a árvore (remover da lista)
  harvest() {
    if (this.isGrown) {
      return true;  // A árvore pode ser colhida
    }
    return false;
  }
}

// Função para adicionar uma árvore
function mousePressed() {
  let newTree = new Tree(mouseX, mouseY);
  trees.push(newTree);
}

// Função principal
function setup() {
  createCanvas(600, 400);
  background(200, 255, 255);  // Cor de fundo do céu
}

// Função que será chamada repetidamente
function draw() {
  background(200, 255, 255);  // Cor de fundo do céu

  // Exibe e faz as árvores crescerem
  for (let i = 0; i < trees.length; i++) {
    trees[i].grow();
    trees[i].display();
    
    // Verifica se a árvore foi colhida ao ser clicada
    if (trees[i].harvest() && dist(mouseX, mouseY, trees[i].x, trees[i].y) < 40) {
      trees.splice(i, 1);  // Remove a árvore da lista
    }
  }
}
